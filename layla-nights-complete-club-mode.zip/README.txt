LAYLA NIGHTS — CLUB MODE COMPLET SANS STRIPE

Ce projet contient tout pour publier ton site en ligne avec :
- Landing page premium
- Formulaire de demande d'accès
- Dashboard admin
- Validation / rejet invités
- Génération ticket QR code
- Page scan entrée
- Bouton WhatsApp pré-rempli
- Backend Node.js simple
- Base de données locale guests.db via NeDB

IMPORTANT
Ce projet ne contient pas Stripe et ne fait aucun paiement en ligne.
Les demandes sont stockées dans guests.db sur le serveur Render.
Pour un vrai gros event, passe plus tard à Supabase/Postgres.

FICHIERS
- public/index.html : site public
- public/admin.html : dashboard admin
- public/ticket.html : ticket invité avec QR
- public/scan.html : validation entrée
- public/hero.png : image background
- server.js : backend API
- package.json : dépendances Node
- .env.example : variables d'environnement

LANCER EN LOCAL
1. Installe Node.js
2. Ouvre le terminal dans ce dossier
3. Lance : npm install
4. Copie .env.example vers .env
5. Modifie ADMIN_KEY si tu veux
6. Lance : npm start
7. Ouvre : http://localhost:4242

PUBLIER SUR RENDER
1. Crée un nouveau repo GitHub et upload tous les fichiers de ce dossier.
2. Va sur Render > New > Web Service.
3. Connecte ton repo.
4. Build Command : npm install
5. Start Command : npm start
6. Ajoute les Environment Variables :
   ADMIN_KEY = un mot de passe admin fort
   PUBLIC_APP_URL = ton URL Render finale, exemple https://layla-nights.onrender.com
   WHATSAPP_PHONE = ton numéro au format international sans +, exemple 212600000000
7. Déploie.

UTILISATION
- Les invités vont sur /index.html et remplissent la demande.
- Toi, tu vas sur /admin.html.
- Tu entres ton ADMIN_KEY.
- Tu acceptes ou rejettes les demandes.
- Quand tu acceptes, un lien ticket est généré.
- Clique WhatsApp pour envoyer le ticket.
- À l'entrée, utilise /scan.html avec la référence du ticket.

NOTES
- Ne partage pas /admin.html publiquement avec ton ADMIN_KEY.
- Garde la localisation privée et envoie-la seulement aux invités acceptés.
