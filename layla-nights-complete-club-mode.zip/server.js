require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const Datastore = require('nedb-promises');

const app = express();
const port = Number(process.env.PORT || 4242);
const adminKey = process.env.ADMIN_KEY || 'admin123';
const publicAppUrl = process.env.PUBLIC_APP_URL || `http://localhost:${port}`;
const whatsappPhone = process.env.WHATSAPP_PHONE || '';

const db = Datastore.create({ filename: path.join(__dirname, 'guests.db'), autoload: true });
db.ensureIndex({ fieldName: 'reference', unique: true }).catch(() => {});
db.ensureIndex({ fieldName: 'ticketId', unique: true, sparse: true }).catch(() => {});

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function requireAdmin(req, res, next) {
  const key = req.headers['x-admin-key'] || req.query.key;
  if (key !== adminKey) return res.status(401).json({ error: 'Admin key invalid.' });
  next();
}

function code(prefix) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

function cleanString(value) {
  return String(value || '').trim().slice(0, 500);
}

function ticketLabel(ticketType) {
  if (ticketType === 'vip') return 'Pass VIP';
  if (ticketType === 'standard') return 'Pass Standard';
  return cleanString(ticketType) || 'Pass Standard';
}

app.get('/api/health', async (_req, res) => {
  const total = await db.count({});
  res.json({ ok: true, service: 'LAYLA NIGHTS Club Mode', total });
});

app.post('/api/requests', async (req, res) => {
  try {
    const body = req.body || {};
    const fullName = cleanString(body.fullName);
    const phone = cleanString(body.phone);
    const email = cleanString(body.email);
    const ticketType = cleanString(body.ticketType || 'standard').toLowerCase();

    if (!fullName || !phone) return res.status(400).json({ error: 'Nom complet et téléphone obligatoires.' });

    const doc = {
      reference: code('REQ'),
      fullName,
      phone,
      email,
      instagram: cleanString(body.instagram),
      ticketType: ticketType === 'vip' ? 'vip' : 'standard',
      ticketLabel: ticketLabel(ticketType),
      quantity: Math.max(1, Math.min(10, Number(body.quantity || 1))),
      message: cleanString(body.message),
      status: 'pending',
      ticketId: '',
      ticketUrl: '',
      qrValue: '',
      usedAt: '',
      gate: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const saved = await db.insert(doc);
    res.json({ request: saved });
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to create request.' });
  }
});

app.get('/api/requests', requireAdmin, async (req, res) => {
  const status = cleanString(req.query.status);
  const filter = status && status !== 'all' ? { status } : {};
  const requests = await db.find(filter).sort({ createdAt: -1 }).limit(500);
  res.json({ requests });
});

app.post('/api/requests/:id/status', requireAdmin, async (req, res) => {
  try {
    const { status } = req.body || {};
    if (!['accepted', 'rejected', 'pending'].includes(status)) return res.status(400).json({ error: 'Invalid status.' });

    const guest = await db.findOne({ _id: req.params.id });
    if (!guest) return res.status(404).json({ error: 'Request not found.' });

    const update = { status, updatedAt: new Date().toISOString() };
    if (status === 'accepted' && !guest.ticketId) {
      update.ticketId = code('TKT');
      update.qrValue = guest.reference;
      update.ticketUrl = `${publicAppUrl}/ticket.html?ref=${encodeURIComponent(guest.reference)}`;
    }

    await db.update({ _id: req.params.id }, { $set: update });
    const updated = await db.findOne({ _id: req.params.id });
    res.json({ request: updated });
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to update request.' });
  }
});

app.get('/api/ticket/:reference', async (req, res) => {
  const ticket = await db.findOne({ reference: req.params.reference });
  if (!ticket) return res.status(404).json({ error: 'Ticket not found.' });
  if (ticket.status !== 'accepted') return res.status(403).json({ error: 'Ticket not accepted yet.', status: ticket.status });
  res.json({ ticket });
});

app.post('/api/scan', requireAdmin, async (req, res) => {
  try {
    const reference = cleanString(req.body.reference);
    const gate = cleanString(req.body.gate || 'Main Gate');
    if (!reference) return res.status(400).json({ error: 'Reference required.' });

    const ticket = await db.findOne({ reference });
    if (!ticket) return res.status(404).json({ error: 'Ticket not found.' });
    if (ticket.status !== 'accepted') return res.status(400).json({ error: 'Guest is not accepted.', ticket });
    if (ticket.usedAt) return res.status(409).json({ error: 'Ticket already used.', ticket });

    await db.update({ _id: ticket._id }, { $set: { usedAt: new Date().toISOString(), gate, updatedAt: new Date().toISOString() } });
    const updated = await db.findOne({ _id: ticket._id });
    res.json({ ticket: updated });
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to scan ticket.' });
  }
});

app.get('/api/config', (_req, res) => {
  res.json({ whatsappPhone, publicAppUrl });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(port, () => console.log(`LAYLA NIGHTS running on http://localhost:${port}`));
